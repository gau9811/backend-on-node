const express = require("express")
const app = express();


app.get('/',(req,res)=>{
    res.send('hello world')
})

app.get('/about',(req,res)=>{
    res.send('<h1>I am about page</h1>')

})


app.get('/ContactUs',(req,res)=>{
    res.send('Contact US +9811055854')
})

app.get('/User/:id/:status/:status_id/',(req,res)=>{
    res.send(req.params)
})

app.get('/flights/:from-to:',(req,res)=>{
    res.send(req.params)
})

app.get('/services',(req,res)=>{
    res.send('<ul><li>Web Development</li><li>logo Design</li><li> matt</li></ul>')
})


app.get('/services',(req,res)=>{
    res.json({nanme:'shyam ' , phoneno:'98110055854'})
})

app.get('/services',(req,res)=>{
    res.status(200).json({nanme:'shyam ' , phoneno:'98110055854'})
})

app.post('/login',(req,res)=>{
    res.send('login sucess')
})

app.delete('/login delete',(req,res)=>{
    res.send('login delete')
})

app.listen(3000,()=>console.log('server is running at port 3000........'))
