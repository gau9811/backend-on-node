const  express = require('express')
const server = express();

let mycon = function(req,res,next){
    console.log('I am middleware')
    next();
}

let mycone = function(req,res,next){
   req.requireTime = Date.now()
   next()
}

server.use(mycone);


server.get('/',(req,res)=>{
    res.send('hello world' + 'and time is:' + req.requireTime)
})

server.listen(3000,()=> console.log(' is running at port 3000....'))