const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const PersonSchema = new Schema({
  name: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true
  },
  password: {
    type: String,
    required: true
  },
  username: {
    type: String
  },
  profilepic: {
    type: String,
    default: "https://www.google.com/url?sa=i&source=images&cd=&ved=2ahUKEwj6hNj0g-vjAhXIfSsKHebpBmcQjRx6BAgBEAQ&url=https%3A%2F%2Fpixabay.com%2Fillustrations%2Fprofile-profile-picture-human-face-2398782%2F&psig=AOvVaw0K0UeDiOnhq7X72SBqVcEF&ust=1565070311238478"
  },
  date: {
    type: Date,
    default: Date.now
  }
});

module.exports = Person = mongoose.model("myPerson", PersonSchema);