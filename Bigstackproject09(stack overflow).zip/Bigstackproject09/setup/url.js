module.exports={
    secret:"mystrongsecret"
};