const express = require("express");
const mongoose = require("mongoose");
const bodyparser = require("body-parser");
const passport = require("passport");

//bring all routes
const auth = require("./routes/api/auth");
const questions = require("./routes/api/questions");
const profile = require("./routes/api/profile");

// Express using app 
const app = express();

//Middleware for bodyparser
app.use(bodyparser.urlencoded({ extended: false }));
app.use(bodyparser.json());

//Attempt to connect to database
 var db = mongoose.connect('mongodb+srv://gaurav:gau9811@cluster0-a4djl.mongodb.net/test?retryWrites=true&w=majority',{useNewUrlParser: true});
     db.then(() => console.log("MongoDB connected successfully"))
     db.catch(err => console.log(err));

//passport middleware
app.use(passport.initialize());

//Config for JWT strategy
require("./Stratgies/jsonwt")(passport)


//just for testing  -> route
app.get("/", (req, res) => {
  res.send("Hey there Big stack");
});

//actual routes
app.use("/api/auth", auth);
app.use("/api/questions", questions);
app.use("/api/profile", profile);

const port = process.env.PORT || 3000;

app.listen(port, () => console.log(`App is running at ${port}`));