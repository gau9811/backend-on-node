let express = require('express')
let passport = require('passport')
let Strategy = require('passport-facebook').Strategy;


passport.use(new Strategy({
  clientID:"561847817683047",
  clientSecret: "900b315bb15fa2450b864765676f37ca",
  callbackURL: "http://localhost:3000/login/facebook/callback"
},

function(accessToken,refreshToken,profile,cb){
   
    return cb(null,profile)
   }
  )
);

passport.serializeUser(function(user,cb){
    cb(null,user)
});

passport.deserializeUser(function(obj,cb){
    cb(null,obj)
});

// create express app
var app = express();

//set views dir
app.set("views",__dirname +"/views");
app.set("view engine","ejs");

app.use(require('morgan')('combined'));
app.use(require('cookie-parser')());
app.use(require('body-parser').urlencoded({extended:true}));
app.use(require('express-session')({secret:'lc app',resave:true, saveUninitialized: true}));

//@route  -  GET   /
//@desc   -  a route to home page
//@access -  PUBLIC

app.get('/',(req,res)=>{
   res.render('home',{user:req.user});
});

//@route  -  GET   /login
//@desc   -  a route to login page
//@access -  PUBLIC

app.get('/login',(req,res)=>{
    res.render("login");
});

//@route  -  GET   /login/facebook
//@desc   -  a route to facebook auth page
//@access -  PUBLIC

app.get('/login/facebook',
  passport.authenticate('facebook'));


//@route  -  GET   /login/facebook/callbacl
//@desc   -  a route to facebook auth page
//@access -  PUBLIC


  app.get('/login/facebook/callback',
  passport.authenticate('facebook', { failureRedirect: '/login' }),
  function(req, res) {
    // Successful authentication, redirect home.
    res.redirect('/');
  });

//@route  -  GET   /Profile
//@desc   -  a route to facebook auth page
//@access -  PRIVATE

app.get('/profile',require('connect-ensure-login').ensureLoggedIn(),(req,res)=>{
    res.render("profile",{user:req.user});
});

app.listen('3000');

// clientID:"561847817683047",
// clientSecret:"900b315bb15fa2450b864765676f37ca",